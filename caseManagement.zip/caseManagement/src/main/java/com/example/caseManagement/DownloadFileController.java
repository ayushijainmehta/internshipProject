package com.example.caseManagement;

import java.io.File;
import java.nio.file.Path;
import java.util.List;
import java.util.Optional;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
 
import com.fasterxml.jackson.annotation.JsonView;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
 
@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class DownloadFileController {

	@Autowired
	private StorageService storageService;
	
  @Autowired
  FileRepository fileRepository;
  imageProcessing image;
  /*
   * List All Files
   */
    @JsonView(View.FileInfo.class)
  @GetMapping("/api/file/all")
  public List<FileModel> getListFiles() {
    	System.out.print("show files");
    return fileRepository.findAll();
  }
  
  @GetMapping("/api/file/{id}")
  public ResponseEntity<byte[]> getFile(@PathVariable Long id) {
	  FileModel file = fileRepository.findOne(id);
	//FileModel file= image.Pic(file1);
System.out.print("downloading");
	 String filename=file.getName();
		return ResponseEntity.ok()
	          .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getName() + "\"")
	          .body(file.getPic());     
	  
  }
  @GetMapping("/api/file/doc")
  public ResponseEntity<Resource> getDoc() {
	  Resource file = storageService.loadAsResource("document.xlsx");
			return ResponseEntity.ok()
					.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + "document.xlsx" + "\"")
					.body(file);	
  }
}