package com.example.caseManagement;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Autowired;

@Entity(name="accessRequest")

public class accessRequest {
	@Id
	@GeneratedValue
    private Long userid;
    private String email;
    private String description;


  
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

  
	
   public Long getuserid() {
		return userid;
	}
	public void setuser(Long userid) {
		this.userid = userid;
	}
	public String getemail() {
		return email;
	}
	public void setemail(String username) {
		this.email = username;
	}
	
	public accessRequest(String email,String description) {
	
		this.email = email;
		this.description =description;

		

		
	}
	@Override
	public String toString() {
		System.out.print(userid);
		return "accessRequest[userid=" + userid + ", email=" + email + ",description="+description+"]";
	}
	public accessRequest() {
	}
    
}
