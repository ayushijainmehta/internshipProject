package com.example.caseManagement;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.Scanner;

import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excel {
	public static void excel() throws IOException
	{
		
		
		
		String TextfileName ="C:\\Users\\oom\\Desktop\\caseManagement\\documents\\document.txt"; 
		String excelFileName = "C:\\Users\\oom\\Desktop\\caseManagement\\documents\\document.xlsx";
        int i=0,index=0;
        XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet("sheet");
		XSSFFont font=workbook.createFont();
		XSSFFont font1=workbook.createFont();
		XSSFCellStyle style=workbook.createCellStyle();
		CellStyle style1=workbook.createCellStyle();
		
		font.setBold(true);
	    style.setFont(font);
		style1.setWrapText(true);
		
		
		try (BufferedReader br = new BufferedReader(new FileReader(TextfileName))) {
		    String line;
		    Row row;
		    Cell cell;
		    int rowIndex = 0;
	        while ((line = br.readLine()) != null) {
		    	i=0;
		        row = sheet.createRow(rowIndex);
		        String[] tokens = line.split(",");
		        if(rowIndex==0)
		       {
		        
		         cell = row.createCell(i);
		         cell.setCellStyle(style1);
	        	 cell.setCellStyle(style);
	             cell.setCellValue("Index");
	            
	             
		       }
		       else
		       {
		    	   
		        
			       cell = row.createCell(i);
		           cell.setCellStyle(style1);
				   cell.setCellValue(index);
		       }
		      i++;
		      index++;
		     
		       for(int iToken = 0; iToken <tokens.length; iToken++) 
		       {
		    	   cell = row.createCell(i);
		            if(rowIndex==0)
		            {
		                 cell.setCellStyle(style1);
			        	 cell.setCellStyle(style);
		            }
		            else
		            {
		            	cell.setCellStyle(style1);
		            	
		            	 
		            }
		            cell.setCellValue(tokens[iToken]);
		            i++; 
		        }
		       rowIndex++;
		         }
		} 
		catch(Exception e) 
		{
		    e.printStackTrace();
		}
		
		FileOutputStream outputStream = new FileOutputStream(excelFileName);
		    workbook.write(outputStream);	
	}

}
