package com.example.caseManagement;

import java.util.Random;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
@Entity(name="userdetails")
public class registration {
	@Id
	@GeneratedValue
    private Long userid;
	String username;
	private String role;

     String email;
    String password=Password(8);
    public Long getUserid() {
		return userid;
	}
	public void setUserid(Long userid) {
		this.userid = userid;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public registration (String username,String email,String password) {
		this.username = username;
		this.email = email;
		this.password=password;
	
	}
	@Override
	public String toString() {
		System.out.print(userid);
		return "registration [role="+"admin"+",userid=" + userid + ", username=" + username + ", email=" + email + ",password="+password+"]";
	}
	public registration() {
	}
	 static String Password(int len) 
	    { 
	        System.out.println("Generating password using random() : "); 
	        System.out.print("Your new password is : "); 
	  
	        // A strong password has Cap_chars, Lower_chars, 
	        // numeric value and symbols. So we are using all of 
	        // them to generate our password 
	        String Capital_chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"; 
	        String Small_chars = "abcdefghijklmnopqrstuvwxyz"; 
	        String numbers = "0123456789"; 
	                String symbols = "!@#$%^&*_=+-/.?<>)"; 
	  
	  String values = Capital_chars + Small_chars + 
	                        numbers + symbols; 
	  
	        // Using random method 
	        Random rndm_method = new Random(); 
	  
	        char[] password = new char[len]; 
	  
	        for (int i = 0; i < len; i++) 
	        { 
	            // Use of charAt() method : to get character value 
	            // Use of nextInt() as it is scanning the value as int 
	            password[i] = 
	              values.charAt(rndm_method.nextInt(values.length())); 
	  
	        } 
	        String pass=new String(password);
	        return pass; 
	    } 
}
