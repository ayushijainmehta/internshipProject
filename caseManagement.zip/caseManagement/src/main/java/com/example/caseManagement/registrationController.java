package com.example.caseManagement;
import java.io.IOException;
import java.security.Key;
import java.security.SecureRandom;
import java.util.List;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.twilio.rest.api.v2010.account.Message;


@RestController
@RequestMapping("/credentials")
@CrossOrigin(origins="http://localhost:4200", allowedHeaders="*")
public class registrationController {
	@Autowired
	EmailController sendMail;
	@Autowired
	passwordSecurity passwordSecure;
	@Autowired
	private registrationRepository Repository;
	@Autowired
	private accessRepository accessrepo;
	@Autowired
	private SMSService smsService;

	@RequestMapping(value = "/sendSMS", method = RequestMethod.GET)
	public Message sendSMS() {
		return smsService.sendSMS();
	}
	@GetMapping("/showrequest")
	public List<accessRequest> getUsers() {
		return accessrepo.findAll();
	}
    @PostMapping("/signup")
	public registration createCredential(@RequestBody registration register) throws Exception{
    	 KeyGenerator keyGen = KeyGenerator.getInstance("DES");
    	System.out.print(register.password);
    	SecureRandom secRandom = new SecureRandom();
        //Initializing the KeyGenerator
        keyGen.init(secRandom);
        //Creating/Generating a key
      Key key = keyGen.generateKey();
      String stringKey=key.toString();
      System.out.print(stringKey);
      //sending sms via twilio
      smsService.sendSMS();
  sendMail.sendmail(register,stringKey);
    	//System.out.print("decrypted key"+passwordSecure.decrypt(register.password,stringKey));
    	//register.password=passwordSecure.encrypt(register.getPassword(),stringKey);
	
		return Repository.save(register);
	}
		@GetMapping("/login")
	public List<registration> validateUswer() {
		System.out.print("validation");
		return Repository.findAll();
	}
	@PostMapping("/access")
	public accessRequest access(@RequestBody accessRequest access)  {
		System.out.print("data stored");
		return accessrepo.save(access);
	}
	@PostMapping("/contact")
	public Contact contactForm(@RequestBody Contact contact) throws AddressException, MessagingException, IOException {
    sendMail.sendmail(contact);
	System.out.print("trial contact"+contact);
		return contact;
	}
	
	} 
	

