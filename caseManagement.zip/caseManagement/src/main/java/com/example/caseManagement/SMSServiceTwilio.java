package com.example.caseManagement;

import org.springframework.stereotype.Service;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
@Service
public class SMSServiceTwilio implements SMSService{
    // Find your Account Sid and Token at twilio.com/console
	public static final String ACCOUNT_SID = "AC75f98ce68115fab447b61694b0f8f24f";
	  public static final String AUTH_TOKEN = "879171e24148ea6d99dda918e0def700";  
	  @Override
    public Message sendSMS() {
        Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
        
        Message message = Message.creator(
                new com.twilio.type.PhoneNumber("+91-9982378155"),//The phone number you are sending text to
                new com.twilio.type.PhoneNumber("+12564458027"),//The Twilio phone number
                "You can now access case Management portal, Check email for login credentials")
           .create();

    	
        return message;
    }
}