package com.example.caseManagement;

public class View {
	
		  public interface FileInfo {}
		}


