package com.example.caseManagement;

import com.example.caseManagement.User;
import com.example.caseManagement.UserRepository;

import java.security.Security;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.CommandLineRunner;

@SpringBootApplication
public class CaseManagementApplication implements CommandLineRunner{
	
	@Autowired
	private registrationRepository Repository;
	 @Resource
	  StorageService storageService;
	public static void main(String[] args) {
		SpringApplication.run(CaseManagementApplication.class, args);
	}
	@Override
	public void run(String... args) throws Exception {
		Security.setProperty("crypto.policy", "unlimited");
	//userRepository.save(new User("ayushi",(long)3456,"ctsstudy"));
		
		
		
	}
	
}
