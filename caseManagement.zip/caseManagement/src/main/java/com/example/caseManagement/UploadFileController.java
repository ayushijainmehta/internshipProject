package com.example.caseManagement;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class UploadFileController {
	  
	 @Autowired
	  FileRepository fileRepository;
	  imageProcessing image;

		@Autowired
		private StorageService storageService;
    /*
     * MultipartFile Upload
     */
    @PostMapping("/api/file/upload")
    public String uploadMultipartFile(@RequestParam("file") MultipartFile file) throws IOException {
    	storageService.store(file);
    	
    	String path="C:\\Users\\oom\\Desktop\\caseManagement\\upload-dir\\"+file.getOriginalFilename();
    	File f=image.Pic(path);
    	 // FileInputStream input = new FileInputStream(file);
    	 //MultipartFile file1=(MultipartFile) f;
    	  byte[] bFile = Files.readAllBytes(new File(path).toPath());
    	try {	
        FileModel filemode = new FileModel(f.getName(),"text/html",bFile);
        fileRepository.save(filemode);
        return "File uploaded successfully! -> filename = " + file.getOriginalFilename();
    } catch (  Exception e) {
      return "FAIL! Maybe You had uploaded the file before or the file's size > 500KB";
    }    
    }
}