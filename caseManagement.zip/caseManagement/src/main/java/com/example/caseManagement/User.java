package com.example.caseManagement;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Autowired;

@Entity(name="caseManagement")

public class User {
	@Id
	@GeneratedValue
    private Long userid;
    private String username;
    private String description;
    private Long caseid;
    private String casename;
	private String status;

  
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

    public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
   public Long getuserid() {
		return userid;
	}
	public void setuser(Long userid) {
		this.userid = userid;
	}
	public String getusername() {
		return username;
	}
	public void setusername(String username) {
		this.username = username;
	}
	public Long getcaseid() {
		return caseid;
	}
	public void setcaseid(Long caseid) {
		this.caseid = caseid;
	}
	public String getcasename() {
		return casename;
	}
	public void setcasename(String casename) {
		this.casename = casename;
	}
	public User(String username,Long caseid,String casename,String description,String status) {
	
		this.username = username;
		this.description =description;
		this.status =status;
		this.casename = casename;
		this.caseid=caseid;
		

		
	}
	@Override
	public String toString() {
		System.out.print(userid);
		return "User [userid=" + userid + ", username=" + username + ", casename=" + casename + ",caseid="+caseid+",description="+description+",status="+status+"]";
	}
	public User() {
	}
    
}
