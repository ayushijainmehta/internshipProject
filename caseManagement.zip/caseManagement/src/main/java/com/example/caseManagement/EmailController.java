package com.example.caseManagement;

import java.io.IOException;
import java.util.Date;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmailController {
	@Autowired
	passwordSecurity passwordSecure;
	public void sendmail(registration register,String stringKey) throws Exception {
		   Properties props = new Properties();
		   props.put("mail.smtp.auth", "true");
		   props.put("mail.smtp.starttls.enable", "true");
		   props.put("mail.smtp.host", "smtp.gmail.com");
		   props.put("mail.smtp.port", "587");
		   Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			      protected PasswordAuthentication getPasswordAuthentication() {
			         return new PasswordAuthentication("converterf@gmail.com", "@Jain2796");
			      }
			   });
		   Message msg = new MimeMessage(session);
		   msg.setFrom(new InternetAddress("converterf@gmail.com", false));

		   msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(register.email));
		   msg.setSubject("Confirmation mail");
		   System.out.print("secret key is"+stringKey);
		 //  String password=passwordSecure.decrypt(register.password,stringKey);
		   msg.setContent("You have successfully registered on Case Management Portal your username is:"+register.email+"   password is:"+register.password, "text/html");
		
		   msg.setSentDate(new Date());

		   
		   Transport.send(msg);   
		}
	public void sendmail(Contact contact) throws AddressException, MessagingException, IOException {
		   Properties props = new Properties();
		   props.put("mail.smtp.auth", "true");
		   props.put("mail.smtp.starttls.enable", "true");
		   props.put("mail.smtp.host", "smtp.gmail.com");
		   props.put("mail.smtp.port", "587");
		   Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			      protected PasswordAuthentication getPasswordAuthentication() {
			         return new PasswordAuthentication("converterf@gmail.com", "@Jain2796");
			      }
			   });
		   Message msg = new MimeMessage(session);
		   msg.setFrom(new InternetAddress("converterf@gmail.com", false));
           msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse("converterf@gmail.com"));
		   msg.setSubject("Mail from username "+ contact.name);
		   msg.setContent(contact.message, "text/html");
		   msg.setSentDate(new Date());

		   
		   Transport.send(msg);   
		}
	}