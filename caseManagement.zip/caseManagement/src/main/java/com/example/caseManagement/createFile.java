package com.example.caseManagement;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.ListIterator;

import antlr.collections.List;

public class createFile {

	public static void text(java.util.List list) throws FileNotFoundException 
	{
      PrintWriter out = new PrintWriter("C:\\Users\\oom\\Desktop\\caseManagement\\documents\\document.txt");
	  Iterator itr=list.iterator();
	  String columns="Userid,Username,caseId,CaseName,Description";
	  out.println(columns);
	 while(itr.hasNext())
	 {
		 String str=itr.next().toString();
		 String string=str.substring(6,str.length()-1);
		 
		 String finalStr="";
		 int start=0;
		 int end=0;
		 for(int i=0;i<string.length();i++)
		 {
			 
			 if(string.charAt(i)=='=')
			 {
				start=i; 
				
			 }
			 if(string.charAt(i)==',')
			 {
				 end=i;
				 System.out.println(string);
				 finalStr=finalStr+string.substring(start+1,end+1);
				
			 }	 
		
		 }
		 finalStr=finalStr.substring(0,finalStr.length()-1);
		 out.println(finalStr);
	 }
	
	    out.close();
	}
}
