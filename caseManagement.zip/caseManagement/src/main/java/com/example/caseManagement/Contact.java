package com.example.caseManagement;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
public class Contact {

		String name;
		 String message;
	  
	   public String getname() {
			return name;
		}
		public void setname(String name) {
			this.name = name;
		}
		 public String getmessage() {
				return message;
			}
			public void setmessage(String message) {
				this.message = message;
			}
		
		public Contact (String username,String message) {
			this.name = username;
			this.message=message;
		}
		@Override
		public String toString() {
	
			return "contact [ username=" + name + ", message=" + message + "]";
		}
		public Contact() {
		}
		
	}



