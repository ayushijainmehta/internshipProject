package com.example.caseManagement;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface accessRepository extends JpaRepository<accessRequest,Long>{

}
