export class Sign {
    userid:number;
role:string;
email:string;
username:string;
 
}
