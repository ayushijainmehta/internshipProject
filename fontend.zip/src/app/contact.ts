export class login {
    email:string;
password:string;
 
}
export class Contact {
name:string;
message:string;
    
}
