import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import{UserService}  from '../../shared-service/user.service';
import{User}  from '../../user';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-serviceList',
  templateUrl: './serviceList.component.html',
  styleUrls: ['./serviceList.component.css']
})

export class ServiceListComponent implements OnInit {
   public users:User[];
  constructor(private _userService:UserService, private _router:Router) { }
  ngOnInit() {
     this._userService.getUsers().subscribe((users)=>{
       console.log(users);
        this.users=users;
      },(error)=>{
        console.log(error);
      })
  }
updateUser(user){  
     this._userService.setter(user);
     this._router.navigate(['/statusUpdate']);


   }
}