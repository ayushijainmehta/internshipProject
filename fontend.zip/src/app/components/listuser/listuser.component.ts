import { Component, OnInit } from '@angular/core';
import{UserService}  from '../../shared-service/user.service';
import{User}  from '../../user';
import{Sign}  from '../../sign';
import{Router}  from '@angular/router';
import{SignupService}  from '../../shared-service/signup.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-listuser',
  templateUrl: './listuser.component.html',
  styleUrls: ['./listuser.component.scss']
})
export class ListuserComponent implements OnInit {
public users:User[];
  private sign:Sign;


  constructor(private signupService:SignupService,private _userService:UserService, private _router:Router) { }

  ngOnInit() {
  this.sign=this.signupService.getter();

    console.log("hi "+this.sign.email)
      this._userService.getUsers().subscribe((users)=>{
       console.log(users);
        this.users=users;
      },(error)=>{
        console.log(error);
      })
   
  }
  uploadFile()
  {
    console.log("hello");
    this._router.navigate(['/upload']);
   
  }
  deleteUser(user){
    this._userService.deleteUser(user.userid).subscribe((data)=>{
        this.users.splice(this.users.indexOf(user),1);
    },(error)=>{
      console.log(error);
    });
    
  }

   updateUser(user){  
     this._userService.setter(user);
     this._router.navigate(['/new']);
   }
   newUser(){
   let user = new User();
    this._userService.setter(user);
     this._router.navigate(['/new']);
   
   }

}
