import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import {StatusUserFormComponent } from './components/status-form/status-form.component';

describe('UserFormComponent', () => {
  let component: StatusUserFormComponent;
  let fixture: ComponentFixture<StatusUserFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StatusUserFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StatusUserFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
