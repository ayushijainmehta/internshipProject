export class Access {
    userid:number;
    email:string;
    description:string;
}
