import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{RouterModule, Routes}   from '@angular/router';
import{HttpModule}   from '@angular/http';
import{FormsModule}   from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { ListuserComponent } from './components/listuser/listuser.component';
import { UserFormComponent } from './components/user-form/user-form.component';
import { NavComponent } from './nav/nav.component';
import { ServiceListComponent } from './components/serviceList/serviceList.component';
import { LogoutComponent } from './logout/logout.component';
import { ContactComponent } from './contact/contact.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import{UserService}   from './shared-service/user.service';
import { AuthGaurdService } from './service/auth-gaurd.service';
import { AuthenticationService } from './service/authentication.service';
import{SignupService}  from './shared-service/signup.service';
import {StatusUserFormComponent } from './components/status-form/status-form.component';
import { DashComponent } from './dash/dash.component';
import {AccessComponent} from './access/access.component';
import { DetailsUploadComponent } from './upload/details-upload/details-upload.component';
import { FormUploadComponent } from './upload/form-upload/form-upload.component';
import { ListUploadComponent } from './upload/list-upload/list-upload.component';
import { UploadFileService} from './upload/upload-file.service';
import { HttpClientModule } from '@angular/common/http';
const appRoutes:Routes=[
 {path:'list', component:ListuserComponent},
  {path:'new', component:UserFormComponent},
    {path:'contact', component:ContactComponent},
     {path:'', component:HomeComponent},
{ path: 'logout', component: LogoutComponent},
     {path:'about', component:AboutComponent},
 {path:'providerList', component:ServiceListComponent},
  {path:'statusUpdate', component:StatusUserFormComponent},
   {path:'dash', component:DashComponent},
     {path:'accessrequests', component:AccessComponent},
      {path:'details', component: DetailsUploadComponent},
       {path:'upload', component:FormUploadComponent},
        {path:'list', component: ListUploadComponent}

 ];

@NgModule({
exports: [RouterModule],
  declarations: [
    AppComponent,
    ListuserComponent,
    UserFormComponent,
    NavComponent,
ServiceListComponent,
     LogoutComponent,
    ContactComponent,
    AboutComponent,
    HomeComponent,
    StatusUserFormComponent,
     DashComponent,
     AccessComponent,
      DetailsUploadComponent,
    FormUploadComponent,
    ListUploadComponent,
  ],
  imports: [
     ReactiveFormsModule,
    BrowserModule,
    HttpModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [UserService,AuthGaurdService,AuthenticationService,SignupService,UploadFileService],
  bootstrap: [AppComponent]
})
export class AppModule { }
