import { Access } from './access';

describe('Access', () => {
  it('should create an instance', () => {
    expect(new Access()).toBeTruthy();
  });
});
