import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
@Injectable()
export class AuthenticationService {

  constructor(private router: Router) { }
checkDatabase(email,details)
{
  console.log("checking database")
  
var flag=true;
console.log("Entered By user   "+email);
 for(var i=0;i<details.length;i++)
    {
      
       if (email === details[i].email)
{
  console.log("exists")
return false;

}
    }
    console.log("hello cas3es")
    return flag;
}
 authenticateRole(details,username) {
    var flag=false;
   var role=''
   console.log("hello ayushi")
 for(var i=0;i<details.length;i++)
    {
    
    if (details[i].email==username) {
 role=details[i].role;
 console.log("role of "+username+"is  "+role)
      break;

    }
   
  }
  console.log(role)
  return role;
  }
  authenticate(username, password,details) {
    var flag=false;
    
    console.log(details)
 for(var i=0;i<details.length;i++)
    {
      
  console.log(username)
 
    if (username === details[i].email && password === details[i].password) {
        console.log("checking"+details[i].email)
      sessionStorage.setItem('username',username)
      flag=true;
      break;
    
    } else {
      flag=false;
      
    }
 
  }
   
  return flag;
  }
  isUserLoggedIn() {
    let user = sessionStorage.getItem('username')
    console.log(!(user === null))
    return !(user === null)
  }

  logOut() {
    sessionStorage.removeItem('username')
  }
}