import { Component, OnInit } from '@angular/core';
import{Router}  from '@angular/router';

import{Access}  from '../access';
import { AuthenticationService } from '../service/authentication.service';
import{Sign}  from '../sign';

import{SignupService}  from '../shared-service/signup.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-access',
  templateUrl: './access.component.html',
  styleUrls: ['./access.component.css']
})
export class AccessComponent implements OnInit {
public access:Access[];
public details:Sign[];

  private sign:Sign;

 messageForm: FormGroup;
  messageFormLogin: FormGroup;
  submitted = false;
  success = false;

  constructor(private loginService:AuthenticationService,private formBuilder:FormBuilder,private _signupService:SignupService,private router: Router)
   {  this.messageForm = this.formBuilder.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      role: ['', [Validators.required]],
    
     
    })

   }

  ngOnInit() {
        this.sign=this._signupService.getter();
    console.log("disaplya request")
    this._signupService.getRequests().subscribe((access)=>{
       console.log(access);
        this.access=access;
      },(error)=>{
        console.log(error);
      })
  }

onSubmit()
  {
    this.submitted = true;
       if (this.messageForm.invalid) {
      return;
    }
    this.success = true;
    console.log("submitted")
this.processForm();
  }

   processForm(){
  console.log("storing in database")
  this._signupService.createCredential(this.sign).subscribe((user)=>{
         console.log(user);
        
    
       },(error)=>{
         console.log(error);
       });
       document.getElementById('id04').style.display='none';
            
                  document.getElementById('id05').style.display='block';
                  document.getElementById('id04').style.display='none';
    }

}
