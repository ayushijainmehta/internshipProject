import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import{Contact}  from '../contact';
import{SignupService}  from '../shared-service/signup.service';
import{Router}  from '@angular/router';
@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.scss']
})
export class ContactComponent implements OnInit {

  messageForm: FormGroup;
  submitted = false;
  success = false;
  private details:Contact[];
  
  private contact:Contact;
 
  constructor(private signupService:SignupService,private formBuilder: FormBuilder,private router:Router) { 
    this.messageForm = this.formBuilder.group({
      name: ['', Validators.required],
      message: ['', Validators.required]
    })
  }

  onSubmit() {
    this.submitted = true;

    if (this.messageForm.invalid) {
      return;
    }
     this.success = true;
     
         console.log("submitted")
this.processForm();
    
  }
processForm()
{

  console.log("hello ayushi")
   //console.log(this.contact)
  this.signupService.sendMessage(this.contact).subscribe((user)=>{
         console.log(user);
       
       },(error)=>{
         console.log(error);
       });
  

   
}
  ngOnInit() {
     this.contact=this.signupService.getterContact();
  }

}
