import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import{Router}  from '@angular/router';
import{SignupService}  from '../shared-service/signup.service';
import{Access}  from '../access';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent {
private access:Access;

ngOnInit()
{   this.access=this._signupService.acessgetter();
}
 constructor(private _signupService:SignupService,private router: Router,private formBuilder: FormBuilder) { 

  }
  onSubmit()
  {
     this._signupService.grantAccess(this.access).subscribe((user)=>{
         console.log(user);
         console.log("request sent to admin")
         document.getElementById('id03').style.display='none'
        this.router.navigate(['']);

     return;
          },(error)=>{
         console.log(error);
       });

       document.getElementById('raise').style.display='block';
  }

}
