export class User {
    userid:Number;
    caseid:Number;
username:string;
    casename:string;
    status:string;
    Description:string;
}
