import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../service/authentication.service';
import{Sign}  from '../sign';
import{Router}  from '@angular/router';
import{SignupService}  from '../shared-service/signup.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.scss']
})
export class NavComponent implements OnInit {

  public details:Sign[];
  private sign:Sign;

  messageFormLogin: FormGroup;
  submitted = false;
  success = false;

  username = ''
  password = ''
  invalidLogin = false
  constructor(private loginService:AuthenticationService,private _signupService:SignupService,private router: Router,private _rotuer:Router,private formBuilder: FormBuilder, private loginservice: AuthenticationService) { 
 
    this.messageFormLogin = this.formBuilder.group({
      loginname: ['', Validators.required],
 loginpassword: ['', Validators.required]
    })
  }

  ngOnInit() {
    this.sign=this._signupService.getter();
  }
   onSubmitLogin() {
    this.submitted = true;

    if (this.messageFormLogin.invalid) {
      return;
    }
console.log("submiitedd form")
    this.success = true;
     this.processFormLogin();
  }
     processFormLogin(){
      this._signupService.getDetails().subscribe((details)=>{
      this.details=details;

       if (this.loginservice.authenticate(this.username, this.password, this.details)
    ) {
      console.log("user exists")
      document.getElementById('id02').style.display='none';
      document.getElementById('loginSuccess').style.display='block'
     if(this.loginservice.authenticateRole(details,this.username)=="customer")
     {
       console.log("customers dashboard")
;
this.router.navigate(['list'])
     }
     else if(this.loginservice.authenticateRole(details,this.username)=="admin")
     {
       console.log("Admins dashboard")
this.router.navigate(['dash'])
     }
     else {
       console.log("providers dashboard")
       this.router.navigate(['providerList'])
     }
      this.invalidLogin = false;
    } else
    this.router.navigate([''])
      this.invalidLogin = true;
    }
  
  ,(error)=>{
         console.log(error);
       });  
       
  }
 
/*onSubmit()
  {
    this.submitted = true;
       if (this.messageForm.invalid) {
      return;
    }
    this.success = true;
    console.log("submitted")
this.processForm();
  }

   processForm(){

  console.log(this.sign.email)
    this._signupService.getDetails().subscribe((details)=>{
      this.details=details;
  
       if (this.loginservice.checkDatabase(this.sign.email,this.details)
    ) {
     console.log("insertion into databse");
     this._signupService.createCredential(this.sign).subscribe((user)=>{
         console.log(user);
         document.getElementById('id01').style.display='none'
         
          this._rotuer.navigate(['']);

     return;
          },(error)=>{
         console.log(error);
       });

    } else
    this._rotuer.navigate(['signup'])
 
    }
     
  ,(error)=>{
         console.log(error);
       });
      
    }*/
    

}