import { Injectable } from '@angular/core';
import{Http, Response, Headers, RequestOptions} from '@angular/http';
import{Observable}   from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import{Sign}  from '../sign';
import{Contact}  from '../contact';
import{Access}  from '../access';
@Injectable()
export class SignupService {

   private baseUrl:string='http://localhost:8080/credentials';
  private headers = new Headers({'Content-Type':'application/json'});
  private options = new RequestOptions({headers:this.headers});
  private sign = new Sign();
    private access= new Access();
  private contact=new Contact();
  constructor(private _http:Http) { }
   getRequests(){

    return this._http.get(this.baseUrl+'/showrequest',this.options).map((response:Response)=>response.json())
      .catch(this.errorHandler);
  }
createCredential(sign:Sign){

    return this._http.post(this.baseUrl+'/signup',JSON.stringify(sign),this.options).map((response:Response)=>response.json())
      .catch(this.errorHandler);
  }
  grantAccess(access:Access){

    return this._http.post(this.baseUrl+'/access',JSON.stringify(access),this.options).map((response:Response)=>response.json())
      .catch(this.errorHandler);
  }
  getDetails(){

    return this._http.get(this.baseUrl+'/login',this.options).map((response:Response)=>response.json())
      .catch(this.errorHandler);
  }
  sendMessage(contact:Contact)
  {
    console.log("service method"+contact.name)
     return this._http.post(this.baseUrl+'/contact',JSON.stringify(contact),this.options).map((response:Response)=>response.json())
      .catch(this.errorHandler);
  }
  errorHandler(error:Response){

     return Observable.throw(error||"SERVER ERROR");
  }

   setter(sign:Sign){
     this.sign=sign;
 }
   getter(){
    return this.sign;
  }
   acessgetter(){
    return this.access;
  }
   setterContact(contact:Contact){
    this.contact=contact;
  }
  getterContact(){
  
    return this.contact;
  }
  
}
